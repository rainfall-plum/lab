`define IF_TO_ID_WD 64
`define ID_TO_IF_WD 33
`define ID_TO_EXE_WD 148
`define EXE_TO_MEM_WD 71
`define MEM_TO_WB_WD 70
`define WB_TO_ID_WD 38
